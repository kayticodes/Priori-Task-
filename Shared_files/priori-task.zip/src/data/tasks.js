// The id of stores will be unique
const tasks = [
    { name: 'Austin',priority: 'Austin', due_date: 'TX', time: 'Austin', description: 'TX' },
    { name: 'New Orleans', priority: 'New Orleans', due_date: 'LA', time: 'New Orleans', description: 'TX' },
    { name: 'San Francisco', priority: 'New Orleans',  due_date: 'CA', time: 'New Orleans', description: 'TX' },
	{ name: 'San Francisco', priority: 'New Orleans',  due_date: 'CA', time: 'New Orleans', description: 'TX' },
];

export default tasks;